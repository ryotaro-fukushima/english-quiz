#include "scanning.h"

long skip_number(const GoString *src, long *p) {
    return skip_number_1(src, p);
}